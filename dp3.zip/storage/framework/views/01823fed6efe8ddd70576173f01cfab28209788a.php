<!--begin::Global Javascript Bundle(used by all pages)-->
<script src="<?php echo e(asset('keenthemes/plugins/global/plugins.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('keenthemes/js/scripts.bundle.js')); ?>"></script>
<!--end::Global Javascript Bundle--><?php /**PATH D:\laragon\www\DP3\resources\views/theme/guest/js.blade.php ENDPATH**/ ?>