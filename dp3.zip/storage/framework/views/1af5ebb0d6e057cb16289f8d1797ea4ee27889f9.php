<div id="content_list">
    <div class="card rounded-0 bgi-no-repeat bgi-position-x-end bgi-size-cover" style="background-color: #663259;background-size: auto 100%; background-image: url(<?php echo e(asset('keenthemes/media/misc/taieri.svg')); ?>)">
        <!--begin::body-->
        <div class="card-body container pt-10 pb-8">
            <!--begin::Title-->
            <div class="d-flex align-items-center">
                <h1 class="fw-bold me-3 text-white">Daftar Pertanyaan</h1>
                <span class="fw-bold text-white opacity-50"></span>
            </div>
            <!--end::Title-->
            <!--begin::Wrapper-->
            <div class="d-flex flex-column">
                <!--begin::Block-->
                <div class="d-lg-flex align-lg-items-center">
                    <!--begin::Simple form-->
                    
                    <!--end::Simple form-->
                    <!--begin::Action-->
                    <div class="d-flex align-items-center">
                        
                    </div>
                    <!--end::Action-->
                </div>
                <!--end::Block--> 
            </div>
            <!--end::Wrapper-->
        </div>
        <!--end::body-->
    </div>
    <!--end::Search form-->
    <div class="content d-flex flex-column flex-column-fluid" id="kt_content">
        <!--begin::Container-->
        <div class="container" id="kt_content_container">
            <!--begin::details View-->
            <div class="card mb-5 mb-xl-10">
                <!--begin::Card body-->
                <div class="card-body p-9">
                    <!--begin::Row-->
                    <div class="row mb-4">
                        <!--begin::Label-->
                        <div class="col-sm-12 col-md-12">
                            <div class="table-responsive">
                                <!--begin::Entry-->
                                <div class="d-flex flex-column-fluid mt-5">
                                    <!--begin::Container-->
                                    <div class="container">
                                        <!--begin::Card-->
                                        <form id="registration">
                                            <input type="hidden" value="<?php echo e($collection->user_id); ?>" name="id">
                                            <?php
                                                $kelolaPenilaian = \App\Models\KelolaPenilaian::get();
                                                $kelolaPenilaian2 = \App\Models\KelolaPenilaian::get();
                                                $kelolaPenilaian3 = \App\Models\KelolaPenilaian::get();
                                                $kelolaPenilaian4 = \App\Models\KelolaPenilaian::get();
                                            ?>
                                            <nav>
                                              <div class="nav nav-pills nav-fill" id="nav-tab" role="tablist">
                                                <a class="nav-link active" id="step1-tab" data-bs-toggle="tab" href="#step1">Kompentensi Pedagogik</a>
                                                <a class="nav-link" id="step2-tab" data-bs-toggle="tab" href="#step2">Kompetensi Profesional</a>
                                                <a class="nav-link" id="step3-tab" data-bs-toggle="tab" href="#step3">Etika Moral dan Kepribadian</a>
                                                <a class="nav-link" id="step3-tab" data-bs-toggle="tab" href="#step4">Budaya Institusi dan Sosial Kemasyarakatan</a>
                                              </div>
                                            </nav>
                                            <div class="tab-content py-4">
                                              <div class="tab-pane fade show active" id="step1">
                                                <?php $__currentLoopData = $kelolaPenilaian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($value->kategori == "Kompentensi Pedagogik"): ?>
                                                    <div class="mb-3">
                                                        <p>
                                                            <strong><?php echo e($value->nama); ?></strong>
                                                        </p>
                                                    </div>

                                                    <div class="text-center mb-3">
                                                        <div class="d-flex mw-500px mb-5" data-kt-buttons="true" data-kt-buttons-target=".form-check-image, .form-check-input">
                                                            <!--begin::Col-->
                                                            <div class="col-4">
                                                                <label class="form-check-image active">
                                                                    <div class="form-check form-check-custom form-check-solid">
                                                                        <div class="d-inline mx-3">
                                                                            Bad
                                                                        </div>
                                                                        <input class="form-check-input" type="radio" value="1" name="option2_<?php echo e($key); ?>" title="Bad"/>
                                                                        <input class="form-check-input" type="hidden" value="<?php echo e($value->id); ?>" name="pertanyaan_<?php echo e($key); ?>"/>
                                                                        <input class="form-check-input" type="hidden" value="Bad" name="rubik_<?php echo e($key); ?>"/>
                                                                        <div class="form-check-label">
                                                                            1
                                                                        </div>
                                                                    </div>
                                                                </label>
                                                            </div>
                                                            <div class="col-4">
                                                                <label class="form-check-image active">
                                                                    <div class="form-check form-check-custom form-check-solid">
                                                                        <div class="d-inline mx-3">
                                                                            Poor
                                                                        </div>
                                                                        <input class="form-check-input" type="radio" value="2" name="option2_<?php echo e($key); ?>" title="Poor"/>
                                                                        <input class="form-check-input" type="hidden" value="<?php echo e($value->id); ?>" name="pertanyaan_<?php echo e($key); ?>"/>
                                                                        <input class="form-check-input" type="hidden" value="Poor" name="rubik_<?php echo e($key); ?>"/>
                                                                        <div class="form-check-label">
                                                                            2
                                                                        </div>
                                                                    </div>
                                                                </label>
                                                            </div>
                                                            <div class="col-4">
                                                                <label class="form-check-image active">
                                                                    <div class="form-check form-check-custom form-check-solid">
                                                                        <div class="d-inline mx-3">
                                                                            Fair
                                                                        </div>
                                                                        <input class="form-check-input" type="radio" value="3" name="option2_<?php echo e($key); ?>" title="Fair"/>
                                                                        <input class="form-check-input" type="hidden" value="<?php echo e($value->id); ?>" name="pertanyaan_<?php echo e($key); ?>"/>
                                                                        <input class="form-check-input" type="hidden" value="Fair" name="rubik_<?php echo e($key); ?>"/>
                                                                        <div class="form-check-label">
                                                                            3
                                                                        </div>
                                                                    </div>
                                                                </label>
                                                            </div>
                                                            <div class="col-4">
                                                                <label class="form-check-image active">
                                                                    <div class="form-check form-check-custom form-check-solid">
                                                                        <div class="d-inline mx-3">
                                                                            Good
                                                                        </div>
                                                                        <input class="form-check-input" type="radio" value="4" name="option2_<?php echo e($key); ?>" title="Good"/>
                                                                        <input class="form-check-input" type="hidden" value="<?php echo e($value->id); ?>" name="pertanyaan_<?php echo e($key); ?>"/>
                                                                        <input class="form-check-input" type="hidden" value="Good" name="rubik_<?php echo e($key); ?>"/>
                                                                        <div class="form-check-label">
                                                                            4
                                                                        </div>
                                                                    </div>
                                                                </label>
                                                            </div>
                                                            <div class="col-4">
                                                                <label class="form-check-image active">
                                                                    <div class="form-check form-check-custom form-check-solid">
                                                                        <div class="d-inline mx-3">
                                                                            Good
                                                                        </div>
                                                                        <input class="form-check-input" type="radio" value="5" name="option2_<?php echo e($key); ?>" title="Good"/>
                                                                        <input class="form-check-input" type="hidden" value="<?php echo e($value->id); ?>" name="pertanyaan_<?php echo e($key); ?>"/>
                                                                        <input class="form-check-input" type="hidden" value="Good" name="rubik_<?php echo e($key); ?>"/>
                                                                        <div class="form-check-label">
                                                                            5
                                                                        </div>
                                                                    </div>
                                                                </label>
                                                            </div>
                                                            <div class="col-4">
                                                                <label class="form-check-image active">
                                                                    <div class="form-check form-check-custom form-check-solid">
                                                                        <div class="d-inline mx-3">
                                                                            Very Good
                                                                        </div>
                                                                        <input class="form-check-input" type="radio" value="6" name="option2_<?php echo e($key); ?>" title="Very Good"/>
                                                                        <input class="form-check-input" type="hidden" value="<?php echo e($value->id); ?>" name="pertanyaan_<?php echo e($key); ?>"/>
                                                                        <input class="form-check-input" type="hidden" value="Very Good" name="rubik_<?php echo e($key); ?>"/>
                                                                        <div class="form-check-label">
                                                                            6
                                                                        </div>
                                                                    </div>
                                                                </label>
                                                            </div>
                                                            <div class="col-4">
                                                                <label class="form-check-image active">
                                                                    <div class="form-check form-check-custom form-check-solid">
                                                                        <div class="d-inline mx-3">
                                                                            Excellent
                                                                        </div>
                                                                        <input class="form-check-input" type="radio" value="7" name="option2_<?php echo e($key); ?>" title="Excellent"/>
                                                                        <input class="form-check-input" type="hidden" value="<?php echo e($value->id); ?>" name="pertanyaan_<?php echo e($key); ?>"/>
                                                                        <input class="form-check-input" type="hidden" value="Excellent" name="rubik_<?php echo e($key); ?>"/>
                                                                        <div class="form-check-label">
                                                                            7
                                                                        </div>
                                                                    </div>
                                                                </label>
                                                            </div>
                                                        </div>
                                                        
                                                    </div>
                                                    <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                              </div>
                                              <div class="tab-pane fade" id="step2">
                                                <?php $__currentLoopData = $kelolaPenilaian2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($value->kategori == "Kompetensi Profesional"): ?>
                                                    <div class="mb-3">
                                                        <p>
                                                            <strong><?php echo e($value->nama); ?></strong>
                                                        </p>
                                                    </div>

                                                    <div class="text-center mb-3">
                                                        <div class="d-flex mw-500px mb-5" data-kt-buttons="true" data-kt-buttons-target=".form-check-image, .form-check-input">
                                                            <!--begin::Col-->
                                                            <div class="col-4">
                                                                <label class="form-check-image active">
                                                                    <div class="form-check form-check-custom form-check-solid">
                                                                        <div class="d-inline mx-3">
                                                                            Bad
                                                                        </div>
                                                                        <input class="form-check-input" type="radio" value="1" name="option2_<?php echo e($key); ?>" title="Bad"/>
                                                                        <input class="form-check-input" type="hidden" value="<?php echo e($value->id); ?>" name="pertanyaan_<?php echo e($key); ?>"/>
                                                                        <input class="form-check-input" type="hidden" value="Bad" name="rubik_<?php echo e($key); ?>"/>
                                                                        <div class="form-check-label">
                                                                            1
                                                                        </div>
                                                                    </div>
                                                                </label>
                                                            </div>
                                                            <div class="col-4">
                                                                <label class="form-check-image active">
                                                                    <div class="form-check form-check-custom form-check-solid">
                                                                        <div class="d-inline mx-3">
                                                                            Poor
                                                                        </div>
                                                                        <input class="form-check-input" type="radio" value="2" name="option2_<?php echo e($key); ?>" title="Poor"/>
                                                                        <input class="form-check-input" type="hidden" value="<?php echo e($value->id); ?>" name="pertanyaan_<?php echo e($key); ?>"/>
                                                                        <input class="form-check-input" type="hidden" value="Poor" name="rubik_<?php echo e($key); ?>"/>
                                                                        <div class="form-check-label">
                                                                            2
                                                                        </div>
                                                                    </div>
                                                                </label>
                                                            </div>
                                                            <div class="col-4">
                                                                <label class="form-check-image active">
                                                                    <div class="form-check form-check-custom form-check-solid">
                                                                        <div class="d-inline mx-3">
                                                                            Fair
                                                                        </div>
                                                                        <input class="form-check-input" type="radio" value="3" name="option2_<?php echo e($key); ?>" title="Fair"/>
                                                                        <input class="form-check-input" type="hidden" value="<?php echo e($value->id); ?>" name="pertanyaan_<?php echo e($key); ?>"/>
                                                                        <input class="form-check-input" type="hidden" value="Fair" name="rubik_<?php echo e($key); ?>"/>
                                                                        <div class="form-check-label">
                                                                            3
                                                                        </div>
                                                                    </div>
                                                                </label>
                                                            </div>
                                                            <div class="col-4">
                                                                <label class="form-check-image active">
                                                                    <div class="form-check form-check-custom form-check-solid">
                                                                        <div class="d-inline mx-3">
                                                                            Good
                                                                        </div>
                                                                        <input class="form-check-input" type="radio" value="4" name="option2_<?php echo e($key); ?>" title="Good"/>
                                                                        <input class="form-check-input" type="hidden" value="<?php echo e($value->id); ?>" name="pertanyaan_<?php echo e($key); ?>"/>
                                                                        <input class="form-check-input" type="hidden" value="Good" name="rubik_<?php echo e($key); ?>"/>
                                                                        <div class="form-check-label">
                                                                            4
                                                                        </div>
                                                                    </div>
                                                                </label>
                                                            </div>
                                                            <div class="col-4">
                                                                <label class="form-check-image active">
                                                                    <div class="form-check form-check-custom form-check-solid">
                                                                        <div class="d-inline mx-3">
                                                                            Good
                                                                        </div>
                                                                        <input class="form-check-input" type="radio" value="5" name="option2_<?php echo e($key); ?>" title="Good"/>
                                                                        <input class="form-check-input" type="hidden" value="<?php echo e($value->id); ?>" name="pertanyaan_<?php echo e($key); ?>"/>
                                                                        <input class="form-check-input" type="hidden" value="Good" name="rubik_<?php echo e($key); ?>"/>
                                                                        <div class="form-check-label">
                                                                            5
                                                                        </div>
                                                                    </div>
                                                                </label>
                                                            </div>
                                                            <div class="col-4">
                                                                <label class="form-check-image active">
                                                                    <div class="form-check form-check-custom form-check-solid">
                                                                        <div class="d-inline mx-3">
                                                                            Very Good
                                                                        </div>
                                                                        <input class="form-check-input" type="radio" value="6" name="option2_<?php echo e($key); ?>" title="Very Good"/>
                                                                        <input class="form-check-input" type="hidden" value="<?php echo e($value->id); ?>" name="pertanyaan_<?php echo e($key); ?>"/>
                                                                        <input class="form-check-input" type="hidden" value="Very Good" name="rubik_<?php echo e($key); ?>"/>
                                                                        <div class="form-check-label">
                                                                            6
                                                                        </div>
                                                                    </div>
                                                                </label>
                                                            </div>
                                                            <div class="col-4">
                                                                <label class="form-check-image active">
                                                                    <div class="form-check form-check-custom form-check-solid">
                                                                        <div class="d-inline mx-3">
                                                                            Excellent
                                                                        </div>
                                                                        <input class="form-check-input" type="radio" value="7" name="option2_<?php echo e($key); ?>" title="Excellent"/>
                                                                        <input class="form-check-input" type="hidden" value="<?php echo e($value->id); ?>" name="pertanyaan_<?php echo e($key); ?>"/>
                                                                        <input class="form-check-input" type="hidden" value="Excellent" name="rubik_<?php echo e($key); ?>"/>
                                                                        <div class="form-check-label">
                                                                            7
                                                                        </div>
                                                                    </div>
                                                                </label>
                                                            </div>
                                                        </div>
                                                        
                                                    </div>
                                                    <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                              </div>
                                              <div class="tab-pane fade" id="step3">
                                                <?php $__currentLoopData = $kelolaPenilaian3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($value->kategori == "Etika Moral dan Kepribadian"): ?>
                                                    <div class="mb-3">
                                                        <p>
                                                            <strong><?php echo e($value->nama); ?></strong>
                                                        </p>
                                                    </div>

                                                    <div class="text-center mb-3">
                                                        <div class="d-flex mw-500px mb-5" data-kt-buttons="true" data-kt-buttons-target=".form-check-image, .form-check-input">
                                                            <!--begin::Col-->
                                                            <div class="col-4">
                                                                <label class="form-check-image active">
                                                                    <div class="form-check form-check-custom form-check-solid">
                                                                        <div class="d-inline mx-3">
                                                                            Bad
                                                                        </div>
                                                                        <input class="form-check-input" type="radio" value="1" name="option2_<?php echo e($key); ?>" title="Bad"/>
                                                                        <input class="form-check-input" type="hidden" value="<?php echo e($value->id); ?>" name="pertanyaan_<?php echo e($key); ?>"/>
                                                                        <input class="form-check-input" type="hidden" value="Bad" name="rubik_<?php echo e($key); ?>"/>
                                                                        <div class="form-check-label">
                                                                            1
                                                                        </div>
                                                                    </div>
                                                                </label>
                                                            </div>
                                                            <div class="col-4">
                                                                <label class="form-check-image active">
                                                                    <div class="form-check form-check-custom form-check-solid">
                                                                        <div class="d-inline mx-3">
                                                                            Poor
                                                                        </div>
                                                                        <input class="form-check-input" type="radio" value="2" name="option2_<?php echo e($key); ?>" title="Poor"/>
                                                                        <input class="form-check-input" type="hidden" value="<?php echo e($value->id); ?>" name="pertanyaan_<?php echo e($key); ?>"/>
                                                                        <input class="form-check-input" type="hidden" value="Poor" name="rubik_<?php echo e($key); ?>"/>
                                                                        <div class="form-check-label">
                                                                            2
                                                                        </div>
                                                                    </div>
                                                                </label>
                                                            </div>
                                                            <div class="col-4">
                                                                <label class="form-check-image active">
                                                                    <div class="form-check form-check-custom form-check-solid">
                                                                        <div class="d-inline mx-3">
                                                                            Fair
                                                                        </div>
                                                                        <input class="form-check-input" type="radio" value="3" name="option2_<?php echo e($key); ?>" title="Fair"/>
                                                                        <input class="form-check-input" type="hidden" value="<?php echo e($value->id); ?>" name="pertanyaan_<?php echo e($key); ?>"/>
                                                                        <input class="form-check-input" type="hidden" value="Fair" name="rubik_<?php echo e($key); ?>"/>
                                                                        <div class="form-check-label">
                                                                            3
                                                                        </div>
                                                                    </div>
                                                                </label>
                                                            </div>
                                                            <div class="col-4">
                                                                <label class="form-check-image active">
                                                                    <div class="form-check form-check-custom form-check-solid">
                                                                        <div class="d-inline mx-3">
                                                                            Good
                                                                        </div>
                                                                        <input class="form-check-input" type="radio" value="4" name="option2_<?php echo e($key); ?>" title="Good"/>
                                                                        <input class="form-check-input" type="hidden" value="<?php echo e($value->id); ?>" name="pertanyaan_<?php echo e($key); ?>"/>
                                                                        <input class="form-check-input" type="hidden" value="Good" name="rubik_<?php echo e($key); ?>"/>
                                                                        <div class="form-check-label">
                                                                            4
                                                                        </div>
                                                                    </div>
                                                                </label>
                                                            </div>
                                                            <div class="col-4">
                                                                <label class="form-check-image active">
                                                                    <div class="form-check form-check-custom form-check-solid">
                                                                        <div class="d-inline mx-3">
                                                                            Good
                                                                        </div>
                                                                        <input class="form-check-input" type="radio" value="5" name="option2_<?php echo e($key); ?>" title="Good"/>
                                                                        <input class="form-check-input" type="hidden" value="<?php echo e($value->id); ?>" name="pertanyaan_<?php echo e($key); ?>"/>
                                                                        <input class="form-check-input" type="hidden" value="Good" name="rubik_<?php echo e($key); ?>"/>
                                                                        <div class="form-check-label">
                                                                            5
                                                                        </div>
                                                                    </div>
                                                                </label>
                                                            </div>
                                                            <div class="col-4">
                                                                <label class="form-check-image active">
                                                                    <div class="form-check form-check-custom form-check-solid">
                                                                        <div class="d-inline mx-3">
                                                                            Very Good
                                                                        </div>
                                                                        <input class="form-check-input" type="radio" value="6" name="option2_<?php echo e($key); ?>" title="Very Good"/>
                                                                        <input class="form-check-input" type="hidden" value="<?php echo e($value->id); ?>" name="pertanyaan_<?php echo e($key); ?>"/>
                                                                        <input class="form-check-input" type="hidden" value="Very Good" name="rubik_<?php echo e($key); ?>"/>
                                                                        <div class="form-check-label">
                                                                            6
                                                                        </div>
                                                                    </div>
                                                                </label>
                                                            </div>
                                                            <div class="col-4">
                                                                <label class="form-check-image active">
                                                                    <div class="form-check form-check-custom form-check-solid">
                                                                        <div class="d-inline mx-3">
                                                                            Excellent
                                                                        </div>
                                                                        <input class="form-check-input" type="radio" value="7" name="option2_<?php echo e($key); ?>" title="Excellent"/>
                                                                        <input class="form-check-input" type="hidden" value="<?php echo e($value->id); ?>" name="pertanyaan_<?php echo e($key); ?>"/>
                                                                        <input class="form-check-input" type="hidden" value="Excellent" name="rubik_<?php echo e($key); ?>"/>
                                                                        <div class="form-check-label">
                                                                            7
                                                                        </div>
                                                                    </div>
                                                                </label>
                                                            </div>
                                                        </div>
                                                        
                                                    </div>
                                                    <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                              </div>
                                              <div class="tab-pane fade" id="step4">
                                                <?php $__currentLoopData = $kelolaPenilaian4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($value->kategori == "Budaya Institusi dan Sosial Kemasyarakatan"): ?>
                                                    <div class="mb-3">
                                                        <p>
                                                            <strong><?php echo e($value->nama); ?></strong>
                                                        </p>
                                                    </div>

                                                    <div class="text-center mb-3">
                                                        <div class="d-flex mw-500px mb-5" data-kt-buttons="true" data-kt-buttons-target=".form-check-image, .form-check-input">
                                                            <!--begin::Col-->
                                                            <div class="col-4">
                                                                <label class="form-check-image active">
                                                                    <div class="form-check form-check-custom form-check-solid">
                                                                        <div class="d-inline mx-3">
                                                                            Bad
                                                                        </div>
                                                                        <input class="form-check-input" type="radio" value="1" name="option2_<?php echo e($key); ?>" title="Bad"/>
                                                                        <input class="form-check-input" type="hidden" value="<?php echo e($value->id); ?>" name="pertanyaan_<?php echo e($key); ?>"/>
                                                                        <input class="form-check-input" type="hidden" value="Bad" name="rubik_<?php echo e($key); ?>"/>
                                                                        <div class="form-check-label">
                                                                            1
                                                                        </div>
                                                                    </div>
                                                                </label>
                                                            </div>
                                                            <div class="col-4">
                                                                <label class="form-check-image active">
                                                                    <div class="form-check form-check-custom form-check-solid">
                                                                        <div class="d-inline mx-3">
                                                                            Poor
                                                                        </div>
                                                                        <input class="form-check-input" type="radio" value="2" name="option2_<?php echo e($key); ?>" title="Poor"/>
                                                                        <input class="form-check-input" type="hidden" value="<?php echo e($value->id); ?>" name="pertanyaan_<?php echo e($key); ?>"/>
                                                                        <input class="form-check-input" type="hidden" value="Poor" name="rubik_<?php echo e($key); ?>"/>
                                                                        <div class="form-check-label">
                                                                            2
                                                                        </div>
                                                                    </div>
                                                                </label>
                                                            </div>
                                                            <div class="col-4">
                                                                <label class="form-check-image active">
                                                                    <div class="form-check form-check-custom form-check-solid">
                                                                        <div class="d-inline mx-3">
                                                                            Fair
                                                                        </div>
                                                                        <input class="form-check-input" type="radio" value="3" name="option2_<?php echo e($key); ?>" title="Fair"/>
                                                                        <input class="form-check-input" type="hidden" value="<?php echo e($value->id); ?>" name="pertanyaan_<?php echo e($key); ?>"/>
                                                                        <input class="form-check-input" type="hidden" value="Fair" name="rubik_<?php echo e($key); ?>"/>
                                                                        <div class="form-check-label">
                                                                            3
                                                                        </div>
                                                                    </div>
                                                                </label>
                                                            </div>
                                                            <div class="col-4">
                                                                <label class="form-check-image active">
                                                                    <div class="form-check form-check-custom form-check-solid">
                                                                        <div class="d-inline mx-3">
                                                                            Good
                                                                        </div>
                                                                        <input class="form-check-input" type="radio" value="4" name="option2_<?php echo e($key); ?>" title="Good"/>
                                                                        <input class="form-check-input" type="hidden" value="<?php echo e($value->id); ?>" name="pertanyaan_<?php echo e($key); ?>"/>
                                                                        <input class="form-check-input" type="hidden" value="Good" name="rubik_<?php echo e($key); ?>"/>
                                                                        <div class="form-check-label">
                                                                            4
                                                                        </div>
                                                                    </div>
                                                                </label>
                                                            </div>
                                                            <div class="col-4">
                                                                <label class="form-check-image active">
                                                                    <div class="form-check form-check-custom form-check-solid">
                                                                        <div class="d-inline mx-3">
                                                                            Good
                                                                        </div>
                                                                        <input class="form-check-input" type="radio" value="5" name="option2_<?php echo e($key); ?>" title="Good"/>
                                                                        <input class="form-check-input" type="hidden" value="<?php echo e($value->id); ?>" name="pertanyaan_<?php echo e($key); ?>"/>
                                                                        <input class="form-check-input" type="hidden" value="Good" name="rubik_<?php echo e($key); ?>"/>
                                                                        <div class="form-check-label">
                                                                            5
                                                                        </div>
                                                                    </div>
                                                                </label>
                                                            </div>
                                                            <div class="col-4">
                                                                <label class="form-check-image active">
                                                                    <div class="form-check form-check-custom form-check-solid">
                                                                        <div class="d-inline mx-3">
                                                                            Very Good
                                                                        </div>
                                                                        <input class="form-check-input" type="radio" value="6" name="option2_<?php echo e($key); ?>" title="Very Good"/>
                                                                        <input class="form-check-input" type="hidden" value="<?php echo e($value->id); ?>" name="pertanyaan_<?php echo e($key); ?>"/>
                                                                        <input class="form-check-input" type="hidden" value="Very Good" name="rubik_<?php echo e($key); ?>"/>
                                                                        <div class="form-check-label">
                                                                            6
                                                                        </div>
                                                                    </div>
                                                                </label>
                                                            </div>
                                                            <div class="col-4">
                                                                <label class="form-check-image active">
                                                                    <div class="form-check form-check-custom form-check-solid">
                                                                        <div class="d-inline mx-3">
                                                                            Excellent
                                                                        </div>
                                                                        <input class="form-check-input" type="radio" value="7" name="option2_<?php echo e($key); ?>" title="Excellent"/>
                                                                        <input class="form-check-input" type="hidden" value="<?php echo e($value->id); ?>" name="pertanyaan_<?php echo e($key); ?>"/>
                                                                        <input class="form-check-input" type="hidden" value="Excellent" name="rubik_<?php echo e($key); ?>"/>
                                                                        <div class="form-check-label">
                                                                            7
                                                                        </div>
                                                                    </div>
                                                                </label>
                                                            </div>
                                                        </div>
                                                        
                                                    </div>
                                                    <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                              </div>
                                            </div>
                                            <div class="row justify-content-between">
                                              <div class="col-auto">
                                                <button id="tombol_simpan" onclick="handle_upload('#tombol_simpan','#registration','<?php echo e(route('staff.survey.store')); ?>','POST','Simpan');" class="btn btn-primary">Simpan</button>
                                              </div>
                                            </div>
                                          </form>
                                        <!--end::Card-->
                                    </div>
                                    <!--end::Container-->
                                </div>
                                <!--end::Entry-->
                            </div>
                        </div>
                        <!--end::Col-->
                    </div>
                    <!--end::Row-->
                </div>
                <!--end::Card body-->
            </div>
            <!--end::Row-->
        </div>
        <!--end::Container-->
    </div>
</div>
<script>
    var registrationForm = $('#registration');
    var formValidate = registrationForm.validate({
        errorClass: 'is-invalid',
        errorPlacement: () => false
    });

    const wizard = new Enchanter('registration', {}, {
        onNext: () => {
        if (!registrationForm.valid()) {
            formValidate.focusInvalid();
            return false;
        }
        }
    });
</script>
<?php /**PATH D:\laragon\www\DP3\resources\views/page/staff/assignPenilai/show.blade.php ENDPATH**/ ?>