<table class="table table-rounded table-striped border gy-7 gs-7">
    <thead>
        <tr class="fw-bold fs-6 text-gray-800 border-bottom border-gray-200">
            <th>Nama Kelas</th>
            <th>Nama Pelajaran</th>
            <th>Total Jadwal</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $collection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($item->kelas); ?></td>
            <td><?php echo e($item->pelajaran); ?></td>
            <td><?php echo e($item->total_jadwal); ?></td>
            <td>
                <a href="<?php echo e(route('guru.room.show',$item->id)); ?>">Data Siswa</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH C:\laragon\www\akademik\resources\views/page/guru/room/list.blade.php ENDPATH**/ ?>