<table class="table table-rounded table-striped border gy-7 gs-7">
    <thead>
        <tr class="fw-bold fs-6 text-gray-800 border-bottom border-gray-200">
            <th>Nama</th>
            <th>Pertanyaan Survey</th>
            <th>Rubik</th>
            <th>Hasil Survey</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $collection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($item->name); ?></td>
            <td><?php echo e($item->nama); ?></td>
            <td><?php echo e($item->rubik); ?></td>
            <td><?php echo e($item->skor); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php echo e($collection->links('theme.app.pagination')); ?><?php /**PATH D:\laragon\www\DP3\resources\views/page/staff/survey/list.blade.php ENDPATH**/ ?>